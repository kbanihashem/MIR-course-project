from typing import List, Dict


def train(training_docs: List[Dict]):
    pass


def classify(doc: Dict) -> int:
    return 1


